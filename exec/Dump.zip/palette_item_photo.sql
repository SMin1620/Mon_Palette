-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 3.39.252.81    Database: palette
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `item_photo`
--

DROP TABLE IF EXISTS `item_photo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_photo` (
  `item_photo_id` bigint NOT NULL,
  `item_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_id` bigint DEFAULT NULL,
  PRIMARY KEY (`item_photo_id`),
  KEY `FK6nter5bnd3ks2by16n0rkncd1` (`item_id`),
  CONSTRAINT `FK6nter5bnd3ks2by16n0rkncd1` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_photo`
--

LOCK TABLES `item_photo` WRITE;
/*!40000 ALTER TABLE `item_photo` DISABLE KEYS */;
INSERT INTO `item_photo` VALUES (1,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/2265c680-526a-6571-aec4-b4724dbd4035디올립스틱.jfif',1),(2,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/2e59fa22-1ff7-96f7-d9ad-5954d08c18d4아이라이너.webp',2),(3,'string',3),(4,'string',4),(5,'https://image.oliveyoung.co.kr/uploads/images/goods/400/10/0000/0016/A00000016455902ko.jpg?l=ko',5),(6,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/a679bb49-65e5-2cb7-2574-fcecc0c57d03다운로드.jfif',6),(7,'https://image.oliveyoung.co.kr/uploads/images/goods/400/10/0000/0018/A00000018546517ko.jpg?l=ko',7),(8,'https://image.oliveyoung.co.kr/uploads/images/goods/400/10/0000/0012/A00000012387908ko.jpg?l=ko',8),(9,'https://image.oliveyoung.co.kr/uploads/images/goods/400/10/0000/0016/A00000016971108ko.jpg?l=ko',9),(10,'https://image.oliveyoung.co.kr/uploads/images/goods/400/10/0000/0018/A00000018744502ko.jpg?l=ko',10),(11,'https://image.oliveyoung.co.kr/uploads/images/goods/400/10/0000/0013/A00000013733004ko.jpg?l=ko',11),(12,'https://image.oliveyoung.co.kr/uploads/images/goods/550/10/0000/0018/A00000018070207ko.jpg?l=ko',12),(13,'https://image.oliveyoung.co.kr/uploads/images/goods/400/10/0000/0015/A00000015486501ko.jpg?l=ko',13);
/*!40000 ALTER TABLE `item_photo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-18 11:30:11
