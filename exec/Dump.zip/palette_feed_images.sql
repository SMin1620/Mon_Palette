-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 3.39.252.81    Database: palette
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `feed_images`
--

DROP TABLE IF EXISTS `feed_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feed_images` (
  `feed_image_id` bigint NOT NULL,
  `image_path` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `feed_id` bigint DEFAULT NULL,
  PRIMARY KEY (`feed_image_id`),
  KEY `FK6gxr0px9hj154hulck32w5unw` (`feed_id`),
  CONSTRAINT `FK6gxr0px9hj154hulck32w5unw` FOREIGN KEY (`feed_id`) REFERENCES `feeds` (`feed_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feed_images`
--

LOCK TABLES `feed_images` WRITE;
/*!40000 ALTER TABLE `feed_images` DISABLE KEYS */;
INSERT INTO `feed_images` VALUES (1,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/2f4d062f-7e6c-da88-bf05-8c2cf235f53dIMG_1287.jpeg',1),(2,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/de25ac03-2047-e3dd-5480-af78030f682dIMG_1288.jpeg',2),(3,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/954165a5-ed01-c96e-148e-73f8c7502029IMG_1287.jpeg',2),(4,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/d12cbbdf-5167-3bab-d12d-a488f6962a1dIMG_1290.jpeg',3),(5,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/49736052-4782-6fca-2f6b-7246e48784e7IMG_1291.jpeg',4),(6,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/671ca45f-8af3-8692-c25a-c433c1a79d28IMG_1292.jpeg',5),(7,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/b5988e3a-af99-02f3-975d-8345fc366832IMG_1294.jpeg',6),(8,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/c59cc1d4-131a-27de-a5db-f6e3484785d6IMG_1293.jpeg',7),(9,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/c8d5ac2a-9b90-09b4-775a-bc040aaf593cIMG_1294.jpeg',8),(10,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/f5b02395-e689-228a-98fb-dad9a4ad576fIMG_1295.jpeg',8),(11,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/15d05e1f-542f-773e-0005-eed122e8e8aeIMG_1296.jpeg',9),(12,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/ac73e92c-19fa-e5ab-db72-bcbec091a4c0IMG_1301.jpeg',10),(13,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/1cb7a86d-535b-1520-73fa-1ce667ca5791IMG_1301.jpeg',10),(14,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/25fe70f8-a277-9726-d049-a1d9fe783fc4IMG_1302.png',10),(15,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/679f76dc-e205-ff1b-5f31-74c7e622f79fIMG_1300.jpeg',11),(16,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/0302f3fc-6f26-f4d1-6383-36b2eefb48caIMG_1301.jpeg',12),(17,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/2b76b44b-630f-286e-2211-7e61801f1ea0IMG_1299.jpeg',13),(18,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/8b928f66-61af-67d0-a7a3-09324ced3354IMG_1298.webp',14),(19,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/e84ea925-f3f9-2663-24fc-1d97662d146e1.jpg',15),(52,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/583c240b-76ef-56bd-2076-eb9f86cd83eddd.png',52);
/*!40000 ALTER TABLE `feed_images` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-18 11:30:41
