-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 3.39.252.81    Database: palette
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `item_detail_photo`
--

DROP TABLE IF EXISTS `item_detail_photo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_detail_photo` (
  `item_detail_photo_id` bigint NOT NULL,
  `item_detail_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_id` bigint DEFAULT NULL,
  PRIMARY KEY (`item_detail_photo_id`),
  KEY `FKaeic2lbdgc7pu83mxu5tg7y4h` (`item_id`),
  CONSTRAINT `FKaeic2lbdgc7pu83mxu5tg7y4h` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_detail_photo`
--

LOCK TABLES `item_detail_photo` WRITE;
/*!40000 ALTER TABLE `item_detail_photo` DISABLE KEYS */;
INSERT INTO `item_detail_photo` VALUES (1,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/8bd8be92-f577-eee4-c6c2-00636dca1584디올립스틱상세2.jfif',1),(2,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/5a1a5883-dbbd-1f80-2485-ec943efadd9a디올립스틱상세1.jfif',1),(3,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/4448de1f-bf8d-4037-cda0-53b036e09fa5아이라이너상세1.jfif',2),(4,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/5b3b236b-87f2-5ded-37d9-6a9724c2860a아이라이너상세.png',2),(5,'https://image.oliveyoung.co.kr/uploads/images/editor/QuickUpload/C18254/image/20230420154322/qc18_20230420154322.jpg',3),(6,'https://image.oliveyoung.co.kr/uploads/images/editor/QuickUpload/C19092/image/20230724114627/qc19_20230724114627.jpg',4),(7,'https://image.oliveyoung.co.kr/uploads/images/editor/QuickUpload/C18305/image/20230206151949/qc18_20230206151949.jpg',5),(8,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/a34ba20a-4f25-f05b-d6ea-8c9f1cb51e0c다운로드.jfif',6),(9,'https://image.oliveyoung.co.kr/uploads/images/editor/QuickUpload/C19092/image/20230724114627/qc19_20230724114627.jpg',7),(10,'https://image.oliveyoung.co.kr/uploads/images/editor/QuickUpload/C18452/image/20230214110242/qc18_20230214110242.jpg',8),(11,'https://image.oliveyoung.co.kr/uploads/images/editor/QuickUpload/C14647/image/20230301000928/qc14_20230301000928.jpg',9),(12,'https://image.oliveyoung.co.kr/uploads/images/editor/QuickUpload/C19134/image/20230628105545/qc19_20230628105545.jpg',10),(13,'https://image.oliveyoung.co.kr/uploads/images/editor/QuickUpload/C18452/image/20211210155707/qc18_20211210155707.jpg',11),(14,'https://image.oliveyoung.co.kr/uploads/images/editor/QuickUpload/SYS/image/20230303145804/qhee_20230303145804.png',12),(15,'https://images-kr.amoremall.com/fileupload/products/111070000513/detail/2022/10/31/%EB%B8%94%EB%9E%99%EC%BF%A0%EC%85%98%20%EC%83%81%EC%84%B8%ED%8E%98%EC%9D%B4%EC%A7%80_%EC%9D%B4%EB%AF%B8%EC%A7%80_01.jpg',13);
/*!40000 ALTER TABLE `item_detail_photo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-18 11:30:39
