-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 3.39.252.81    Database: palette
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `item_options`
--

DROP TABLE IF EXISTS `item_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_options` (
  `option_id` bigint NOT NULL,
  `option_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stock` int NOT NULL,
  `item_id` bigint DEFAULT NULL,
  PRIMARY KEY (`option_id`),
  KEY `FKhggiv5f76uw3pnx1fu92yxclo` (`item_id`),
  CONSTRAINT `FKhggiv5f76uw3pnx1fu92yxclo` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_options`
--

LOCK TABLES `item_options` WRITE;
/*!40000 ALTER TABLE `item_options` DISABLE KEYS */;
INSERT INTO `item_options` VALUES (1,'장미 빨간색',123,1),(2,'얇은 아이라이너',123,2),(3,'차차틴트',50000,3),(4,'고고틴트',50000,3),(5,'베네틴트',50000,3),(6,'피치뮬리',50000,4),(7,'뮤트코랄',50000,4),(8,'핑크 브리즈',50000,4),(9,'엔비',50000,5),(10,'캔디드',50000,5),(11,'어도어',50000,5),(12,'오렌지',100,6),(13,'레드',100,6),(14,'피치뮬리',50000,7),(15,'뮤트코랄',50000,7),(16,'핑크 브리즈',50000,7),(17,'만다린 오',50000,8),(18,'디보티드 투 칠리',50000,8),(19,'폴 인 러브',50000,8),(20,'스타일 쇼크드',50000,8),(21,'소프티',50000,9),(22,'녹아웃',50000,9),(23,'플레져',50000,9),(24,'시퀀스',50000,9),(25,'스트레인져',50000,9),(26,'픽셀핑크',50000,10),(27,'러브바이트',50000,10),(28,'피치플리스',50000,10),(29,'히든모브',50000,10),(30,'리들러',50000,10),(31,'핑크',50000,11),(32,'러브레드',50000,11),(33,'피치오렌지',50000,11),(34,'무빙무빙',50000,11),(35,'리본',50000,11),(36,'헬씨 코랄',50000,12),(37,'글로잉 레드',50000,12),(38,'핑크 바이브',50000,12),(39,'치어풀 오렌지',50000,12),(40,'리본',50000,12),(41,'21N1',50000,13),(42,'23N1',50000,13),(43,'17N1',50000,13),(44,'17C1',50000,13),(45,'13N1',50000,13);
/*!40000 ALTER TABLE `item_options` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-18 11:30:05
