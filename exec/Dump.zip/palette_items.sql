-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 3.39.252.81    Database: palette
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `items` (
  `item_id` bigint NOT NULL,
  `content` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `create_at` datetime(6) DEFAULT NULL,
  `delete_at` datetime(6) DEFAULT NULL,
  `delivery_fee` int DEFAULT NULL,
  `discount` int DEFAULT NULL,
  `end_at` datetime(6) DEFAULT NULL,
  `is_delete` bit(1) DEFAULT NULL,
  `manufact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `maximum` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int NOT NULL,
  `thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `update_at` datetime(6) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`item_id`),
  KEY `FKft8pmhndq1kntvyfaqcybhxvx` (`user_id`),
  CONSTRAINT `FKft8pmhndq1kntvyfaqcybhxvx` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (1,'디올의 장미를 나타낸색','2023-08-17 15:00:00.000000',NULL,0,0,'2023-08-31 15:00:00.000000',_binary '\0','디올',3,'디올 립스틱',15000,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/2265c680-526a-6571-aec4-b4724dbd4035디올립스틱.jfif',NULL,1),(2,'얇은 디올의 아이라이너','2023-08-17 15:00:00.000000',NULL,0,0,'2023-09-01 15:00:00.000000',_binary '\0','디올',12,'디올 아이라이너',20000,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/2e59fa22-1ff7-96f7-d9ad-5954d08c18d4아이라이너.webp',NULL,1),(3,'수채화처럼 맑고 투명하게 발색되는 리퀴드 틴트','2023-08-18 00:18:52.195000','2023-08-18 09:39:15.000000',0,10,'2023-08-28 00:18:52.195000',_binary '','string',1000,'베네틴트',29000,'https://image.oliveyoung.co.kr/uploads/images/goods/400/10/0000/0013/A00000013115441ko.jpg?l=ko',NULL,10),(4,'맑은 광채 입술을 연출하는 글로우 틴트','2023-08-18 00:18:52.195000','2023-08-18 09:42:06.000000',0,0,'2023-09-28 00:18:52.195000',_binary '','string',1000,'레미유 듀이 플로우 틴트',15200,'https://image.oliveyoung.co.kr/uploads/images/goods/400/10/0000/0018/A00000018546517ko.jpg?l=ko',NULL,10),(5,'생기로운 인상을 선사하는 글로우 틴트','2023-08-18 00:18:52.195000',NULL,0,0,'2023-09-01 00:18:52.195000',_binary '\0','string',1000,'라카 프루티 글램 틴트 ',15000,'https://image.oliveyoung.co.kr/uploads/images/goods/400/10/0000/0016/A00000016455902ko.jpg?l=ko',NULL,10),(6,'디올 립스틱','2023-08-17 15:00:00.000000',NULL,0,0,'2023-08-24 15:00:00.000000',_binary '\0','디올',3,'디올립스틱',15000,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/a679bb49-65e5-2cb7-2574-fcecc0c57d03다운로드.jfif',NULL,5),(7,'생기로운 인상을 선사하는 글로우 틴트','2023-08-18 00:18:52.195000',NULL,0,0,'2023-09-01 00:18:52.195000',_binary '\0','string',1000,'레미유 듀이 플로우 틴트',15000,'https://image.oliveyoung.co.kr/uploads/images/goods/400/10/0000/0018/A00000018546517ko.jpg?l=ko',NULL,10),(8,'건조함 없는 파우더리한 립스틱','2023-08-18 00:18:52.195000',NULL,0,10,'2023-08-29 00:18:52.195000',_binary '\0','string',1000,'MAC 맥 파우더 키스 립스틱',39000,'https://image.oliveyoung.co.kr/uploads/images/goods/400/10/0000/0012/A00000012387908ko.jpg?l=ko',NULL,10),(9,'벨벳 틴트를 압축한 듯한 가벼운 리퀴드 립','2023-08-18 00:18:52.195000',NULL,0,15,'2023-08-29 00:18:52.195000',_binary '\0','string',1000,'무지개맨션 오브제 리퀴드 틴트',18000,'https://image.oliveyoung.co.kr/uploads/images/goods/400/10/0000/0016/A00000016971108ko.jpg?l=ko',NULL,10),(10,'맑은 컬러감과 광택감으로 완성된 빌더블 틴트','2023-08-18 00:18:52.195000',NULL,0,0,'2023-08-29 00:18:52.195000',_binary '\0','string',1000,'헤라 센슈얼 피팅 글로우 틴트',40000,'https://image.oliveyoung.co.kr/uploads/images/goods/400/10/0000/0018/A00000018744502ko.jpg?l=ko',NULL,10),(11,'입술에 가볍게 밀착되는 립','2023-08-18 00:18:52.195000',NULL,0,10,'2023-08-29 00:18:52.195000',_binary '\0','string',1000,'MAC 맥 파우더 키스 리퀴드 립컬러',25000,'https://image.oliveyoung.co.kr/uploads/images/goods/400/10/0000/0013/A00000013733004ko.jpg?l=ko',NULL,10),(12,'입술에 가볍게 밀착되는 립','2023-08-18 00:18:52.195000',NULL,0,0,'2023-08-29 00:18:52.195000',_binary '\0','string',1000,'웨이크메이크 비타민 수분 톡톡 립밤',18000,'https://image.oliveyoung.co.kr/uploads/images/goods/550/10/0000/0018/A00000018070207ko.jpg?l=ko',NULL,10),(13,'세미 매트 쿠션','2023-08-18 00:18:52.195000',NULL,0,0,'2023-08-29 00:18:52.195000',_binary '\0','string',1000,'헤라 블랙 쿠션',33000,'https://image.oliveyoung.co.kr/uploads/images/goods/400/10/0000/0015/A00000015486501ko.jpg?l=ko',NULL,10);
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-18 11:30:28
