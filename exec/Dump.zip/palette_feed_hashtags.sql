-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 3.39.252.81    Database: palette
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `feed_hashtags`
--

DROP TABLE IF EXISTS `feed_hashtags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feed_hashtags` (
  `feed_hashtag_id` bigint NOT NULL,
  `feed_id` bigint DEFAULT NULL,
  `hashtag_id` bigint DEFAULT NULL,
  PRIMARY KEY (`feed_hashtag_id`),
  KEY `FKpu0758lr9fknsfpb4j061wyhw` (`feed_id`),
  KEY `FKgklafylgb9dyerysvoajb0jop` (`hashtag_id`),
  CONSTRAINT `FKgklafylgb9dyerysvoajb0jop` FOREIGN KEY (`hashtag_id`) REFERENCES `hashtags` (`hashtag_id`),
  CONSTRAINT `FKpu0758lr9fknsfpb4j061wyhw` FOREIGN KEY (`feed_id`) REFERENCES `feeds` (`feed_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feed_hashtags`
--

LOCK TABLES `feed_hashtags` WRITE;
/*!40000 ALTER TABLE `feed_hashtags` DISABLE KEYS */;
INSERT INTO `feed_hashtags` VALUES (1,1,1),(2,1,2),(3,2,1),(4,2,3),(5,2,4),(6,3,1),(7,3,3),(8,3,5),(9,4,1),(10,4,2),(11,4,3),(12,4,6),(13,5,7),(14,5,8),(15,5,9),(16,6,7),(17,6,10),(18,6,8),(19,6,11),(20,7,7),(21,7,8),(22,7,12),(23,8,8),(24,8,13),(25,8,7),(26,9,12),(27,9,7),(28,10,14),(29,10,15),(30,10,16),(31,10,17),(32,11,17),(33,11,18),(34,11,19),(35,11,20),(36,12,21),(37,12,22),(38,12,23),(39,12,17),(40,13,24),(41,14,25),(42,14,26),(43,14,27),(44,14,28),(45,15,29),(52,52,52),(53,52,53);
/*!40000 ALTER TABLE `feed_hashtags` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-18 11:30:05
