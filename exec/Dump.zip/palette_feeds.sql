-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 3.39.252.81    Database: palette
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `feeds`
--

DROP TABLE IF EXISTS `feeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feeds` (
  `feed_id` bigint NOT NULL,
  `content` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `create_at` datetime(6) DEFAULT NULL,
  `delete_at` datetime(6) DEFAULT NULL,
  `is_delete` bit(1) DEFAULT NULL,
  `like_count` int DEFAULT NULL,
  `update_at` datetime(6) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`feed_id`),
  KEY `FKa4nmt7wyx9clm9okj61dgd1tw` (`user_id`),
  CONSTRAINT `FKa4nmt7wyx9clm9okj61dgd1tw` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feeds`
--

LOCK TABLES `feeds` WRITE;
/*!40000 ALTER TABLE `feeds` DISABLE KEYS */;
INSERT INTO `feeds` VALUES (1,'오늘 메이크업','2023-08-18 08:07:46.143606',NULL,_binary '\0',1,NULL,1),(2,'오늘 메이크업 어때요?','2023-08-18 08:08:22.629578',NULL,_binary '\0',0,NULL,1),(3,'아침에 소나기옴ㅠ ','2023-08-18 08:09:01.134603',NULL,_binary '\0',0,NULL,1),(4,'오늘 메이크업 맘에들어서','2023-08-18 08:09:36.083506',NULL,_binary '\0',1,NULL,1),(5,'프로필 찍었어욤','2023-08-18 08:13:05.094846',NULL,_binary '\0',1,NULL,5),(6,'유튜브 영상업댓! 찾아와주세욤','2023-08-18 08:13:39.353845',NULL,_binary '\0',0,NULL,5),(7,'겟레디윗미 구경하러와용','2023-08-18 08:14:09.308865',NULL,_binary '\0',0,NULL,5),(8,'스타일링 꿀팁은 안다','2023-08-18 08:14:46.874927',NULL,_binary '\0',0,NULL,5),(9,'비포에프터 확실하죠?','2023-08-18 08:15:14.591610',NULL,_binary '\0',1,NULL,5),(10,'놀러와요\n나잘생김','2023-08-18 08:18:46.146043',NULL,_binary '\0',1,NULL,6),(11,'녹두모공','2023-08-18 08:19:13.036257',NULL,_binary '\0',1,NULL,6),(12,'레오제이 놀러감놀러감\n','2023-08-18 08:19:58.047820',NULL,_binary '\0',1,NULL,6),(13,'화보찍음','2023-08-18 08:20:18.824814',NULL,_binary '\0',1,NULL,6),(14,'컨셉','2023-08-18 08:20:44.217519',NULL,_binary '\0',1,NULL,6),(15,'양념치킨','2023-08-18 08:48:38.446592',NULL,_binary '\0',2,NULL,7),(52,'카리나임 ㅇㅇ','2023-08-18 10:59:42.473747',NULL,_binary '\0',0,NULL,7);
/*!40000 ALTER TABLE `feeds` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-18 11:30:41
