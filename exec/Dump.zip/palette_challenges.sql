-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 3.39.252.81    Database: palette
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `challenges`
--

DROP TABLE IF EXISTS `challenges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `challenges` (
  `challenge_id` bigint NOT NULL,
  `content` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `create_at` datetime(6) DEFAULT NULL,
  `delete_at` datetime(6) DEFAULT NULL,
  `is_delete` bit(1) DEFAULT NULL,
  `like_count` int DEFAULT NULL,
  `update_at` datetime(6) DEFAULT NULL,
  `video` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`challenge_id`),
  KEY `FKle3q0kbl0hsc262e7qnjw6dgw` (`user_id`),
  CONSTRAINT `FKle3q0kbl0hsc262e7qnjw6dgw` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `challenges`
--

LOCK TABLES `challenges` WRITE;
/*!40000 ALTER TABLE `challenges` DISABLE KEYS */;
INSERT INTO `challenges` VALUES (1,'토카토카','2023-08-18 08:20:21.208024',NULL,_binary '\0',0,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/916b7716-3250-a24a-4b1f-8cd24651a51a_talkv_wtSTQLomoP_qeKYp4AGg6NdZM0x58y7F1_talkv_high.mp4',7),(2,'','2023-08-18 09:12:50.082055','2023-08-18 09:16:31.000000',_binary '',0,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/93f91068-5912-4510-e0eb-cf4a15b5ada6.mp4',1),(3,'가영이 메이크업','2023-08-18 09:14:15.103017',NULL,_binary '\0',1,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/715324b0-88b9-be2f-e1f4-1c14ca17d026.mp4',5),(4,'','2023-08-18 09:18:19.456879',NULL,_binary '\0',0,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/d2f8eb17-8a79-13c6-6335-f8537672f017.mp4',1),(5,'예레니카 웹툰 메이크업','2023-08-18 09:21:01.356551',NULL,_binary '\0',0,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/e900bfd9-6ee4-03fc-f0d1-110d924a9094agdangyi-abbareul-ggosyeora-yerenika-webtun-meikeueob-1280-ytshorts.savetube.me.mp4',5),(6,'','2023-08-18 09:21:21.030643',NULL,_binary '\0',1,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/91d423e0-dc16-27f6-c6f1-360201bc1d3a.mp4',1),(7,'','2023-08-18 09:35:57.124604',NULL,_binary '\0',0,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/b1421924-8ee4-5a7a-f2a3-57df66a78845.mp4',1),(8,'페리페라 기상청 컬렉션 잉크더벨벳','2023-08-18 09:37:14.603695',NULL,_binary '\0',0,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/eba85549-0ae7-b718-24ff-bba1b73bef372.mp4',1),(9,'릴리바이레드 앙큼 라이너','2023-08-18 09:38:29.756934',NULL,_binary '\0',0,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/1a299e5d-025b-aaee-5530-bc9193137d5d.mp4',1),(10,'해원 앞머리 자르기','2023-08-18 09:39:32.356894',NULL,_binary '\0',0,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/232c86f7-34ff-9e21-1d2f-e1c8c28d216f2.mp4',1);
/*!40000 ALTER TABLE `challenges` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-18 11:30:40
