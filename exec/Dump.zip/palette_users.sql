-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 3.39.252.81    Database: palette
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` bigint NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `background_image` varchar(5000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birth` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_at` datetime(6) NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_leave` bit(1) NOT NULL,
  `is_oauth` bit(1) DEFAULT NULL,
  `leave_at` datetime(6) DEFAULT NULL,
  `modified_at` datetime(6) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nickname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `personal_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image` varchar(5000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refresh_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('ADMIN','IF','USER') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/1f6f1005-f949-ac22-3201-3e5ebce77ba5.jpg','970830','2023-08-18 05:50:45.683292','email@email.com','male',_binary '\0',_binary '\0',NULL,NULL,'이승민','탈옥한키퍼','$2a$10$SgYJAx3o294vjRwjDxUStOcmONJvw25pNNM5dQz44/m7NBGYN2O9G',NULL,'01011112222','https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/9d5a5e9f-877a-5716-070e-2e92e827952a.webp',NULL,'IF'),(2,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/background.jpg','19999999','2023-08-18 06:10:09.510962','d@email.com','female',_binary '\0',_binary '\0',NULL,NULL,'잉잉','후잉','$2a$10$YhQHLaKA0qhT7ubjNzgd1u7H456WicxQpJ3c8tXNkAipBrcZZAe9i',NULL,'01011111111','https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/baseimg.png',NULL,'IF'),(3,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/background.jpg','970830','2023-08-18 06:36:40.936427','email2@email.com','string',_binary '\0',_binary '\0',NULL,NULL,'짱구','짱구','$2a$10$tbnsXJWiSj0KRe96XfAxnORlnNFVAeAwJuENfnPMLITf4seycGTQ.',NULL,'0114345665','https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/baseimg.png',NULL,'IF'),(4,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/background.jpg',NULL,'2023-08-18 06:52:57.358012','cj5255@pusan.ac.kr',NULL,_binary '\0',_binary '',NULL,NULL,'최진석','최진석','$2a$10$QNngMYHXZSbHJIPa1E.4DOFP9uF1e8np4slcpNDLVwM/MJZB5Ptr6',NULL,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/baseimg.png',NULL,'IF'),(5,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/background.jpg','19990102','2023-08-18 08:11:49.799436','ejjeongs@naver.com','female',_binary '\0',_binary '\0',NULL,NULL,'조은정','안다','$2a$10$6hciAf5We.f/i71Jtonlpu8GFyOuzb/XIcP1jKD1N.hQDpqxkJe/m',NULL,'01026760690','https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/240db569-67a2-e2ab-9dba-5c8eb98502d4fd.jfif',NULL,'IF'),(6,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/background.jpg','19990101','2023-08-18 08:17:49.851065','email3@email.com','male',_binary '\0',_binary '\0',NULL,NULL,'레오제이','레오제이','$2a$10$3EpmA9OGwo9UgDa8IBcvYuaKDMm.SJ8I1bL5O46/S2Lwg3/sgfane',NULL,'01012345678','https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/baseimg.png',NULL,'IF'),(7,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/background.jpg','19970830','2023-08-18 08:18:46.930868','ibb09@naver.com','male',_binary '\0',_binary '\0',NULL,NULL,'이승민','냥뇽녕냥','$2a$10$fAciyyLtcpdKJ2Yqrzi8x.RuA4vZAmfo9VTN1z7qBCMAZOUro381.',NULL,'01035971081','https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/323af7b2-b834-9b36-1fd8-bf6b03aa9fa72.jpg',NULL,'IF'),(8,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/background.jpg','19991010','2023-08-18 08:24:28.550280','email4@email.com','female',_binary '\0',_binary '\0',NULL,NULL,'민스코','민스코','$2a$10$88Uv1xtag9Ud/MY31kISKOyFh4xIyhoJ0ZtDwjt0Zrh33SyxqLWXS',NULL,'01011112223','https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/baseimg.png',NULL,'IF'),(9,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/background.jpg',NULL,'2023-08-18 08:40:32.221665','cj525566@gmail.com',NULL,_binary '\0',_binary '',NULL,NULL,'최진석','최진석','$2a$10$7q3rHWm56V4itb6qOcmDxeWVJJeWxxcX3RPDr45Qy3U9D2O33luke','봄웜톤',NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/baseimg.png',NULL,'IF'),(10,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/background.jpg','19990218','2023-08-18 09:16:15.719056','osb4469@naver.com','female',_binary '\0',_binary '\0',NULL,NULL,'오수빈','쿠쿠루삥뽕','$2a$10$.kEyweN4fraY1Fvx5luaPuW4wyOUB4PrsofwTovK.gif7tA58E8Qy',NULL,'01033766823','https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/baseimg.png',NULL,'IF'),(11,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/background.jpg','19971014','2023-08-18 10:06:41.278459','krkdhs3333@daum.net','male',_binary '\0',_binary '\0',NULL,NULL,'정수완','정수완','$2a$10$HDbxUksvWcRNhPLWVtbQF.fOeVgHW8KfgJxIyB.mC1oLxpiUaiaPC',NULL,'01026595557','https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/baseimg.png',NULL,'IF'),(52,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/background.jpg','00000000','2023-08-18 11:22:10.998715','test@email.com','male',_binary '\0',_binary '\0',NULL,NULL,'컨설턴트','컨설턴트','$2a$10$xFLtIkIZ4tzPmEPYqCGH5eJIgl01bLpYPIE3BfZKigqohht7Y8UzG',NULL,'01000001111','https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/baseimg.png',NULL,'IF'),(53,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/background.jpg','11111111','2023-08-18 11:23:13.112820','test1@email.com','male',_binary '\0',_binary '\0',NULL,NULL,'코치1','코치1','$2a$10$OJTo.VeX5AYt9N0mNXovTOQUV1B8XQX2LZUMji3/DrwINfBy2bC1O',NULL,'01011111112','https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/baseimg.png',NULL,'IF'),(54,NULL,'https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/background.jpg','22222222','2023-08-18 11:23:43.358127','test2@email.com','male',_binary '\0',_binary '\0',NULL,NULL,'코치2','코치2','$2a$10$ylAIX1vs0ee9l8SXsBN29uaDEPJ7I.gMgrMb9hDuqY99VT4r7SZ4i',NULL,'01022222222','https://ssafy9-monpalette.s3.ap-northeast-2.amazonaws.com/baseimg.png',NULL,'IF');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-18 11:30:13
